import imaplib
import email
import re
import sys
import LoginUI
import chardet


def parseHeader(message):
    """
    解析邮件首部
    :param message:
    :return:
    """
    subject = message.get('subject')
    dh = email.header.decode_header(subject)
    subject = str(dh[0][0], dh[0][1])  # .encode('gb2312')
    # 主题
    print('Subject:', subject)
    # 发件人
    print('From:', email.utils.parseaddr(message.get('from'))[1])
    # 收件人
    print('To:', email.utils.parseaddr(message.get('to'))[1])
    # 抄送人
    print('Cc:', email.utils.parseaddr(message.get_all('cc'))[1])


def savefile(filename, data, path):
    """
    保存文件方法（都是保存在指定的根目录下）
    :param filename:
    :param data:
    :param path:
    :return:
    """
    try:
        filepath = path + filename
        print('Saved as ' + filepath)
        f = open(filepath, 'wb')
    except:
        print('filename error')
        f.close()
    f.write(data)
    f.close()


def parseBody(message):
    """
    解析邮件，信体
    :param message:
    :return:
    """
    # 循环信件中的每一个mime的数据块
    for part in message.walk():

        # 这里要判断是否是multipart，是的话，里面的数据是一个message 列表
        if not part.is_multipart():
            charset = part.get_charset()
            # print 'charset: ', charset
            contenttype = part.get_content_type()
            # print 'content-type', contenttype
            name = part.get_param('name')  # 如果是附件，这里就会取出附件的文件名
            if not name:
                # 没有附件，是文本内容
                # part 是Message类
                # print("part type:",type(part))
                # encoding_type 是
                encoding_type = part.get_charset()
                content_type = part.get_content_type()
                # print("content_type",content_type)
                try:
                    if (content_type == 'text/plain'):
                        print(str(part.get_payload(decode=True), 'gbk'))  # gbk读取文本，utf-8读取图片信息...
                        return
                    elif content_type == 'text/html':
                        print(str(part.get_payload(decode=True), 'gbk'))
                        f = open('new.html', 'w', encoding='utf8')
                        a = str(part.get_payload(decode=True), 'gbk')
                        f.write(a)
                        f.close()
                        b = re.compile(u"[\u4e00-\u9fa5]{1,2}")
                        c = b.findall(a)
                        for i in c:
                            print(i, end='')
                        return
                except:
                    if (content_type == 'text/plain'):
                        print(str(part.get_payload(decode=True), 'utf-8'))  # gbk读取文本，utf-8读取图片信息...
                        return
                    elif content_type == 'text/html':
                        print(str(part.get_payload(decode=True), 'gbk'))
                        a = str(part.get_payload(decode=True), 'gbk').encode('gbk')
                        b = re.compile(u"[\u4e00-\u9fa5]{1,2}")
                        c = b.findall(a)
                        for i in c:
                            print(i)
                        return
            else:
                dh = email.header.decode_header(name)
                fname = dh[0][0]
                encode_str = dh[0][1]
                if encode_str != None:
                    if charset == None:
                        fname = fname.decode(encode_str, 'gbk')
                    else:
                        fname = fname.decode(encode_str, charset)
                data = part.get_payload(decode=True)
                # 打印附件名称
                print('Attachment : ' + fname)
                # 保存附件，默认路径是mypath
                if fname != None or fname != '':
                    savefile(fname, data, '')


# 登录函数
def clickbtn1(serv, username, password):
    """
    登录邮箱
    :param host:
    :param username:
    :param password:
    :param port:
    :return:
     """
    p = re.compile('^[A-Za-z0-9\u4e00-\u9fa5]+@[a-zA-Z0-9_-]+(\.[a-zA-Z0-9_-]+)+$')
    x=p.match(username)
    if x==None:
        return "邮箱格式有误！"
    else:
        pass

    try:
        serv = imaplib.IMAP4_SSL(host, 993)  # 使用IMAP4_SSL，通过SSL加密的套接字连接
    except Exception as e:
        serv = imaplib.IMAP4(host, 143)  # 使用IMAP4连接
    try:
        serv.login(username, password)  # 登录邮箱
    except:
        return '登陆失败，请检查您的邮箱和密码是否正确！'
    return '登陆成功！'

#可以通过此函数实现各种功能
def getRecentMail(serv):

    serv.select()  # 参数可以选择收件文件夹
    typ, data = serv.search(None, 'ALL')  # 搜索邮件内容，ALL是搜索所有邮件
    count = 1
    pcount = 1
    for num in data[0].split()[::-1]:
        typ, data = serv.fetch(num, '(RFC822)')
        text = data[0][1]
        new_text = str(text, encoding=chardet.detect(text)['encoding'])  # utf-8 or gb2312
        print(new_text)

        message = email.message_from_string(new_text)  # 转换为email.message对象
        parseHeader(message)
        parseBody(message)
        pcount += 1
        if pcount > count:
            break

    serv.close()
    serv.logout()

if __name__ == '__main__':
    host = "pop.mail_serv.com"
    # username = "3389089691@qq.com"
    # password = "rnhprnvdybxwciec"
    app = LoginUI.QApplication(sys.argv)
    gui = LoginUI.LoginUI()

    sys.exit(app.exec_())
    print('0.4564')
    # print("\n")
    # host2 = "imap.163.com"
    # username2 = "jingyi_d@163.com"
    # passord2 = "shouquanma123"
    # getMail(host2,username2,passord2)
