class ruler():

    def __init__(self):
        self.sender=''
        self.keystr=0
        self.towhere=0