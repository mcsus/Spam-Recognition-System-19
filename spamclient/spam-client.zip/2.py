from retrying import retry
@retry(stop_max_attempt_number=3)
def test():
    # tplt = "{0:{3}^10}\t{1:{3}^20}\t{2:{3}^10}"
    # print(tplt.format('发件人','主要内容','判断结果',chr(12288)))

    ac = ['123']
    ac.append({})
    print(ac)
    a = {[1, 2, 3, 4, 5, 6]}
    b = [1, 2, 3, 4, 5]
    # print(a[len(b):len(a)])
    print(a+b)

try:
    test()
except:
    print('error happended.')


print('program running smooth')


a=[1,2,3]
b=[1,2,3,4]
for i in range(5,7):
    print(i)
