import sys
from PyQt5.QtWidgets import QApplication, QWidget, QPushButton, QVBoxLayout, QLabel




if __name__ == '__main__':
    app = QApplication([])
    win = QWidget()
    label = QLabel('Hello World!')
    label2 = QLabel('fuck')
    layout = QVBoxLayout()
    layout.addWidget(label)
    layout.addWidget(label2)
    win.setLayout(layout)
    win.show()
    sys.exit(app.exec_())