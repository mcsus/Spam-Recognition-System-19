# -*- coding: utf-8 -*-


# Form implementation generated from reading ui file 'clat.ui'

#

# Created by: PyQt5 UI code generator 5.6

#

# WARNING! All changes made in this file will be lost!


from PyQt5 import QtCore, QtGui, QtWidgets


class Ui_Form(object):

    def setupUi(self, Form):
        Form.setObjectName("Form")

        Form.resize(746, 455)

        self.widget = QtWidgets.QWidget(Form)

        self.widget.setGeometry(QtCore.QRect(81, 31, 512, 399))

        self.widget.setObjectName("widget")

        self.gridLayout = QtWidgets.QGridLayout(self.widget)

        self.gridLayout.setContentsMargins(0, 0, 0, 0)

        self.gridLayout.setObjectName("gridLayout")

        self.textBrowser = QtWidgets.QTextBrowser(self.widget)

        self.textBrowser.setObjectName("textBrowser")

        self.gridLayout.addWidget(self.textBrowser, 0, 0, 2, 4)

        self.calendarWidget = QtWidgets.QCalendarWidget(self.widget)

        self.calendarWidget.setObjectName("calendarWidget")

        self.gridLayout.addWidget(self.calendarWidget, 1, 4, 1, 2)

        self.lineEdit = QtWidgets.QLineEdit(self.widget)

        self.lineEdit.setObjectName("lineEdit")

        self.gridLayout.addWidget(self.lineEdit, 2, 0, 1, 5)

        self.pushButton_19 = QtWidgets.QPushButton(self.widget)

        self.pushButton_19.setObjectName("pushButton_19")

        self.gridLayout.addWidget(self.pushButton_19, 4, 0, 1, 1)

        self.pushButton_17 = QtWidgets.QPushButton(self.widget)

        self.pushButton_17.setObjectName("pushButton_17")

        self.gridLayout.addWidget(self.pushButton_17, 4, 1, 1, 1)

        self.pushButton_18 = QtWidgets.QPushButton(self.widget)

        self.pushButton_18.setObjectName("pushButton_18")

        self.gridLayout.addWidget(self.pushButton_18, 4, 2, 1, 1)

        self.pushButton_1 = QtWidgets.QPushButton(self.widget)

        self.pushButton_1.setObjectName("pushButton_1")

        self.gridLayout.addWidget(self.pushButton_1, 4, 3, 1, 3)

        self.pushButton_14 = QtWidgets.QPushButton(self.widget)

        self.pushButton_14.setObjectName("pushButton_14")

        self.gridLayout.addWidget(self.pushButton_14, 6, 0, 1, 1)

        self.pushButton_15 = QtWidgets.QPushButton(self.widget)

        self.pushButton_15.setObjectName("pushButton_15")

        self.gridLayout.addWidget(self.pushButton_15, 6, 1, 1, 1)

        self.pushButton_16 = QtWidgets.QPushButton(self.widget)

        self.pushButton_16.setObjectName("pushButton_16")

        self.gridLayout.addWidget(self.pushButton_16, 6, 2, 1, 1)

        self.pushButton_2 = QtWidgets.QPushButton(self.widget)

        self.pushButton_2.setObjectName("pushButton_2")

        self.gridLayout.addWidget(self.pushButton_2, 6, 3, 1, 3)

        self.pushButton_11 = QtWidgets.QPushButton(self.widget)

        self.pushButton_11.setObjectName("pushButton_11")

        self.gridLayout.addWidget(self.pushButton_11, 8, 0, 1, 1)

        self.pushButton_12 = QtWidgets.QPushButton(self.widget)

        self.pushButton_12.setObjectName("pushButton_12")

        self.gridLayout.addWidget(self.pushButton_12, 8, 1, 1, 1)

        self.pushButton_13 = QtWidgets.QPushButton(self.widget)

        self.pushButton_13.setObjectName("pushButton_13")

        self.gridLayout.addWidget(self.pushButton_13, 8, 2, 1, 1)

        self.pushButton_3 = QtWidgets.QPushButton(self.widget)

        self.pushButton_3.setObjectName("pushButton_3")

        self.gridLayout.addWidget(self.pushButton_3, 8, 3, 1, 3)

        self.pushButton_8 = QtWidgets.QPushButton(self.widget)

        self.pushButton_8.setObjectName("pushButton_8")

        self.gridLayout.addWidget(self.pushButton_8, 9, 0, 1, 1)

        self.pushButton_9 = QtWidgets.QPushButton(self.widget)

        self.pushButton_9.setObjectName("pushButton_9")

        self.gridLayout.addWidget(self.pushButton_9, 9, 1, 1, 1)

        self.pushButton_10 = QtWidgets.QPushButton(self.widget)

        self.pushButton_10.setObjectName("pushButton_10")

        self.gridLayout.addWidget(self.pushButton_10, 9, 2, 1, 1)

        self.pushButton_4 = QtWidgets.QPushButton(self.widget)

        self.pushButton_4.setObjectName("pushButton_4")

        self.gridLayout.addWidget(self.pushButton_4, 9, 3, 1, 3)

        self.pushButton_7 = QtWidgets.QPushButton(self.widget)

        self.pushButton_7.setObjectName("pushButton_7")

        self.gridLayout.addWidget(self.pushButton_7, 10, 0, 1, 2)

        self.pushButton_6 = QtWidgets.QPushButton(self.widget)

        self.pushButton_6.setObjectName("pushButton_6")

        self.gridLayout.addWidget(self.pushButton_6, 10, 2, 1, 1)

        self.pushButton_5 = QtWidgets.QPushButton(self.widget)

        self.pushButton_5.setObjectName("pushButton_5")

        self.gridLayout.addWidget(self.pushButton_5, 10, 3, 1, 3)

        self.pushButton = QtWidgets.QPushButton(self.widget)

        self.pushButton.setObjectName("pushButton")

        self.gridLayout.addWidget(self.pushButton, 2, 5, 1, 1)

        self.retranslateUi(Form)

        QtCore.QMetaObject.connectSlotsByName(Form)

    def retranslateUi(self, Form):
        _translate = QtCore.QCoreApplication.translate

        Form.setWindowTitle(_translate("Form", "Form"))

        self.pushButton_19.setText(_translate("Form", "退出"))

        self.pushButton_17.setText(_translate("Form", "返回"))

        self.pushButton_18.setText(_translate("Form", "清除所有"))

        self.pushButton_1.setText(_translate("Form", "/"))

        self.pushButton_14.setText(_translate("Form", "7"))

        self.pushButton_15.setText(_translate("Form", "8"))

        self.pushButton_16.setText(_translate("Form", "9"))

        self.pushButton_2.setText(_translate("Form", "*"))

        self.pushButton_11.setText(_translate("Form", "4"))

        self.pushButton_12.setText(_translate("Form", "5"))

        self.pushButton_13.setText(_translate("Form", "6"))

        self.pushButton_3.setText(_translate("Form", "+"))

        self.pushButton_8.setText(_translate("Form", "1"))

        self.pushButton_9.setText(_translate("Form", "2"))

        self.pushButton_10.setText(_translate("Form", "3"))

        self.pushButton_4.setText(_translate("Form", "-"))

        self.pushButton_7.setText(_translate("Form", "0"))

        self.pushButton_6.setText(_translate("Form", "."))

        self.pushButton_5.setText(_translate("Form", "="))

        self.pushButton.setText(_translate("Form", "清除缓存"))


