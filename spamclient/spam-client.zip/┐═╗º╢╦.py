import socket
import json

def send_client(action,content):
    link = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    link.connect(('106.52.236.143', 3389))
    while True:
        data = {'action':action,'content':content}
        if not data:
            break
        else:
            link.sendall(repr(data).encode())
            break
    response=link.recv(1023)
    print(str(response,encoding='utf8'))
    if response.strip()=='':
        pass
    else:
        print(eval(response))
    link.close()

if __name__ == '__main__':
    dic=[{'id':1,'owner':'a1','sender':None,'key_word':'才寻鲲','type':'black'}]
    # json1=json.dumps(dic)
    send_client('request-result','hello  我是你爸爸')




