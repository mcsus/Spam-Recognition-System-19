# -*- coding: utf-8 -*-

from PyQt5 import QtWidgets, QtCore
import sys
from PyQt5.QtCore import *
import time
import LoginAndGetMail2_3


# 继承QThread
class Runthread(QtCore.QThread):
    # python3,pyqt5与之前的版本有些不一样
    #  通过类成员对象定义信号对象
    _signal = pyqtSignal(str)
    my_serv=None
    my_rulelist=None
    my_mailadress=None

    def __init__(self, parent=None,serv=None,rulelist=None,mailadress=None):
        super(Runthread, self).__init__()
        self.my_serv=serv
        self.my_rulelist=rulelist
        self.my_mailadress=mailadress

    def __del__(self):
        self.wait()

    def run(self):
        len_list=0
        while True:
            response_result_list=LoginAndGetMail2_3.checkAndJudgeNewMail(self.my_serv,self.my_rulelist)
            if len(response_result_list)>len_list:
                self._signal.emit(str(response_result_list[len_list,len(response_result_list)]))
            else:
                pass


class mywindow(QtWidgets.QWidget):
    def __init__(self):
        super(mywindow, self).__init__()
        self.setupUi(self)
        self.Button_start.clicked.connect(self.start_login)

    def start_login(self):
        # 创建线程
        self.thread = Runthread()
        # 连接信号
        self.thread._signal.connect(self.callbacklog)
        # 开始线程
        self.thread.start()

    def callbacklog(self, msg):
        # 奖回调数据输出到文本框
        # self.textEdit_log.setText(self.textEdit_log.toPlainText() + "\n" + msg + "   " +
        #                           time.strftime("%Y-%m-%d %H:%M:%S", time.localtime()));
        print(msg)



if __name__ == "__main__":
    app = QtWidgets.QApplication(sys.argv)
    myshow = mywindow()
    myshow.show()
    sys.exit(app.exec_())