from Popup_Win import *

app = QtWidgets.QApplication(sys.argv)
win = PopupWin()
win.show(type='default', subject='主题', sender='me',body='测试一哈哈哈哈').showAnimation()
# sys.exit(app.exec_())