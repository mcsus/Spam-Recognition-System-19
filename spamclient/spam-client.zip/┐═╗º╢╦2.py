# import socket
#
# link = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
# link.connect(('localhost', 1024))
#
#
# data=input('>')
# if not data:
#     pass
# link.send(data.encode())
# link.close()

a=['111']
b=['222']
print(a+b)

a=[]
if a[0]==None:
    print(5)