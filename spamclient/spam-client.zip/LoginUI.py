import sys
import LoginAndGetMail
from PyQt5.QtWidgets import *
from PyQt5.QtCore import *
from PyQt5.QtGui import *

class LoginUI(QWidget):
    def __init__(self):
        # 初始化————init__
        super().__init__()
        self.initLoginUI()

    def initLoginUI(self):
        #设置widget组件的大小(w,h)
        self.resize(500,250)
        #设置widget组件的位置居中
        qr = self.frameGeometry()
        cp = QDesktopWidget().availableGeometry().center()
        qr.moveCenter(cp)
        self.move(qr.topLeft())

        #给widget组件设置标题
        self.setWindowTitle('登录')
        #给widget组件设置图标
        self.setWindowIcon(QIcon('2.png'))

        #设置按钮并给按钮命名
        self.btn1 = QPushButton('登录',self)
        #给按钮设置位置(x,y,w,h)
        self.btn1.setGeometry(210,200,75,30)
        #设置按钮样式
        self.btn1.setStyleSheet("QPushButton{color:black}"
                                       "QPushButton:hover{color:red}"
                                       "QPushButton{background-color:lightgreen}"
                                       "QPushButton{border:2px}"
                                       "QPushButton{border-radius:10px}"
                                       "QPushButton{padding:2px 4px}")
        qssStyle='''QLabel{color:black}'''
        # 加载设置好的样式
        self.setStyleSheet(qssStyle)

        #点击按钮触发事件
        self.btn1.clicked.connect(self.clickbtn1)

        #设置lable信息
        self.label1 = QLabel(self)
        self.label1.setGeometry(QRect(212, 5, 100, 30))
        self.label1.setText('圆桌清道夫')
        self.label1.setObjectName('label')

        self.label2 = QLabel(self)
        self.label2.setGeometry(QRect(100,65,50,30))
        self.label2.setText('账号')

        self.label3 = QLabel(self)
        self.label3.setGeometry(QRect(90,130,50,30))
        self.label3.setText('授权码')

        #设置输入框
        self.textbox1 = QLineEdit(self)
        self.textbox1.resize(200,30)
        self.textbox1.move(150,65)

        self.textbox2 = QLineEdit(self)
        self.textbox2.setContextMenuPolicy(Qt.NoContextMenu)
        self.textbox2.setEchoMode(QLineEdit.Password)
        self.textbox2.resize(200,30)
        self.textbox2.move(150,130)

        #show()方法在屏幕上显示出组件
        self.show()

    #点击鼠标触发函数
    def clickbtn1(self):
        #打印出输入框的信息
        textboxValue1 = self.textbox1.text()
        textboxValue2 = self.textbox2.text()
        if textboxValue1==''or textboxValue2=='':
            QMessageBox.question(self, "提示", '请正确输入邮箱账号及授权码',QMessageBox.Ok, QMessageBox.Ok)
        else:
            LoginAndGetMail.getMail('imap.qq.com', textboxValue1, textboxValue2)
            #发送账号
        #清空输入框信息
        # self.textbox1.setText('')
        # self.textbox2.setText('')

    #关闭窗口事件重写
    def closeEvent(self, QCloseEvent):
        reply = QMessageBox.question(self, '警告',"确定关闭当前窗口?", QMessageBox.Yes | QMessageBox.No, QMessageBox.No)
        if reply == QMessageBox.Yes:
            QCloseEvent.accept()
        else:
            QCloseEvent.ignore()

if __name__ == '__main__':
    app = QApplication(sys.argv)
    gui = LoginUI()
    sys.exit(app.exec_())