import imaplib
import email
import re
import sys
import LoginUI
import chardet


# 解析邮件头
def parseHeader(message):
    """
    解析邮件首部
    :param message:
    :return:
    """
    subject = message.get('subject')
    dh = email.header.decode_header(subject)
    subject = str(dh[0][0], dh[0][1])  # .encode('gb2312')
    # 主题
    print('Subject:', subject)
    # 发件人
    print('From:', email.utils.parseaddr(message.get('from'))[1])
    # 收件人
    print('To:', email.utils.parseaddr(message.get('to'))[1])
    # 日期
    print('Date : ' + message["Date"])


# 保存文件
def savefile(filename, data, path):
    """
    保存文件方法（都是保存在指定的根目录下）
    :param filename:
    :param data:
    :param path:
    :return:
    """
    try:
        filepath = path + filename
        print('Saved as ' + filepath)
        f = open(filepath, 'wb')
    except:
        print('filename error')
        f.close()
    f.write(data)
    f.close()


# 解析文件体
def parseBody(message):
    """
    解析邮件体
    :param message:
    :return:
    """
    # 循环信件中的每一个mime的数据块，part是Message类
    for part in message.walk():
        # 如果不是multipart（否则里面的数据是一个message 列表）
        if not part.is_multipart():
            charset = part.get_charset()
            # 如果是附件，这里就会取出附件的文件名
            name = part.get_param('name')
            # 如果没有附件，是文本内容
            if not name:
                # 编码方式
                encoding_type = part.get_charset()
                # 内容类型，一般有image,text/plain,text/html
                content_type = part.get_content_type()
                try:
                    # 如果是纯文本
                    if (content_type == 'text/plain'):
                        # gbk解决中文编码，utf-8解决英文编码
                        # 打印邮件体
                        print(str(part.get_payload(decode=True), 'gbk'))
                        # 只要打印了一次就返回，解决原始邮件体和html版本邮件体重复度读取的问题
                        return
                    # 如果是html
                    elif content_type == 'text/html':
                        # 解析html，获取邮件体
                        print(str(part.get_payload(decode=True), 'gbk'))
                        f = open('new.html', 'w', encoding='utf8')
                        a = str(part.get_payload(decode=True), 'gbk')
                        f.write(a)
                        f.close()
                        b = re.compile(u"[\u4e00-\u9fa5]{1,2}")
                        c = b.findall(a)
                        for i in c:
                            print(i, end='')
                        return
                except:
                    if (content_type == 'text/plain'):
                        print(str(part.get_payload(decode=True), 'utf-8'))
                        return
                    elif content_type == 'text/html':
                        print(str(part.get_payload(decode=True), 'gbk'))
                        a = str(part.get_payload(decode=True), 'gbk').encode('gbk')
                        b = re.compile(u"[\u4e00-\u9fa5]{1,2}")
                        c = b.findall(a)
                        for i in c:
                            print(i)
                        return
            else:
                # 如果有附件，打印附件名并将附件保存到指定目录
                dh = email.header.decode_header(name)
                fname = dh[0][0]
                encode_str = dh[0][1]
                if encode_str != None:
                    if charset == None:
                        fname = fname.decode(encode_str, 'gbk')
                    else:
                        fname = fname.decode(encode_str, charset)
                data = part.get_payload(decode=True)
                # 打印附件名称
                print('Attachment : ' + fname)
                # 保存附件
                #debug，会保存到哪里？
                if fname != None or fname != '':
                    savefile(fname, data, '')


# 登录函数
def clickbtn1(serv, username, password):
    """
    登录邮箱
    :param serv:
    :param username:
    :param password:
    :return:
    """
    p = re.compile('^[A-Za-z0-9\u4e00-\u9fa5]+@[a-zA-Z0-9_-]+(\.[a-zA-Z0-9_-]+)+$')
    x=p.match(username)
    if x==None:
        return "邮箱格式有误！"
    else:
        pass

    try:
        # 使用IMAP4_SSL，通过SSL加密的套接字连接
        serv = imaplib.IMAP4_SSL(host, 993)
    except Exception as e:
        try:
            # 使用IMAP4连接
            serv = imaplib.IMAP4(host, 143)
        except Exception as e:
            return("连接失败，请检查服务器和端口名称！")

    try:
        # 登陆邮箱
        serv.login(username, password)
    except:
        return '登陆失败，请检查您的邮箱和密码是否正确！'
    return '登陆成功！'


def monitor(host,username,password):
    try:
        # 使用IMAP4_SSL，通过SSL加密的套接字连接
        serv = imaplib.IMAP4_SSL(host, 993)
    except Exception as e:
        try:
            # 使用IMAP4连接
            serv = imaplib.IMAP4(host, 143)
        except Exception as e:
            print("连接失败，请检查服务器和端口名称！")

    try:
        # 登陆邮箱
        serv.login(username, password)
    except:
        print('登陆失败，请检查您的邮箱和密码是否正确！')
    """
    监控，如果有新邮件则实时输出新邮件信息
    :param host:
    :param username:
    :param password:
    :return:
    """
    serv.select('INBOX')
    typ, data = serv.search(None, 'ALL')
    num_1 = len(data[0].split())
    num_2 = 0

    # 循环实现监听功能
    while True:
        serv.select('INBOX')
        typ, data = serv.search(None, 'ALL')
        num_2 = len(data[0].split())
        # 如果有新的邮件
        if (num_1 < num_2):
            print("有新邮件啦！")
            # 打印新邮件信息(num_before-1到num_new)
            for num in range(num_1, num_2):
                print("打印第",num,"封邮件")
                typ, data = serv.fetch(num, '(RFC822)')
                # 数据元组
                text = data[0][1]
                # 编码方式
                encoding = chardet.detect(text)['encoding']
                new_text = str(text, encoding)
                # 转换为email.Message对象
                message = email.message_from_string(new_text)
                # 解析邮件头部
                parseHeader(message)
                # 解析邮件体
                parseBody(message)
            # 更新邮件数量
            num_1 = num_2

    serv.close()
    serv.logout()


#可以通过此函数实现各种功能
def getRecentMail(serv):
    """
    实现各种功能函数
    :param serv:
    :return:
    """

    # IMAP4.select([mailbox[, readonly]])第一个参数是邮箱名，默认是INBOX，readonly是只能读，不能修改
    serv.select()
    ## 第二个参数：All,Unseen,Seen,Recent,Answered, Flagged，返回
    typ, data = serv.search(None, 'ALL')

    """
    # 计数
    count = 1
    pcount = 1
    """
    # 通过编号遍历search出的所有邮件
    for num in data[0].split()[::-1]:
        # 打印邮件序号
        typ, data = serv.fetch(num, '(RFC822)')
        # 数据元组
        text = data[0][1]
        new_text = str(text, encoding=chardet.detect(text)['encoding'])  # utf-8 or gb2312
        # print(new_text)
        # 转换为email.message对象
        message = email.message_from_string(new_text)
        # 解析邮件头部
        parseHeader(message)
        # 解析邮件体
        parseBody(message)
        """
        pcount += 1
        if pcount > count:
            break
        """

    serv.close()
    serv.logout()


if __name__ == '__main__':
    """
    host = "pop.mail_serv.com"
    # username = "3389089691@qq.com"
    # password = "rnhprnvdybxwciec"
    app = LoginUI.QApplication(sys.argv)
    gui = LoginUI.LoginUI()

    sys.exit(app.exec_())
    print('0.4564')
    # print("\n")
    # host2 = "imap.163.com"
    # username2 = "jingyi_d@163.com"
    # passord2 = "shouquanma123"
    # getMail(host2,username2,passord2)
    """
    host = "imap-mail.outlook.com"
    username = "jingyi_d@outlook.com"
    password = "532148605Djk"
    monitor(host,username,password)
