import imaplib
import email
import re
import time
import chardet


def parseHeader(message):
    """
    解析邮件首部
    :param message:
    :return:
    """
    subject = message.get('subject')
    dh = email.header.decode_header(subject)
    if dh[0][1] is None:
        subject = str(dh[0][0])
    else:
        subject = str(dh[0][0], dh[0][1])  # .encode('gb2312')
    # 主题
    print('Subject:', subject)
    # 发件人
    print('From:', email.utils.parseaddr(message.get('from'))[1])
    # 收件人
    print('To:', email.utils.parseaddr(message.get('to'))[1])
    # 日期
    print('Date : ' + message["Date"])


def parseBody(message):
    """
    解析邮件，信体
    :param message:
    :return:
    """
    # 循环信件中的每一个mime的数据块
    for part in message.walk():
        # 这里要判断是否是multipart，是的话，里面的数据是一个message 列表
        if not part.is_multipart():
            charset = part.get_charset()
            # 如果是附件，这里就会取出附件的文件名
            name = part.get_param("name")
            if name is None:
                # 编码方式
                encoding_type = part.get_charset()
                # 内容类型，一般有image,text/plain,text/html
                content_type = part.get_content_type()

                try:
                    # 如果是纯文本
                    if (content_type == 'text/plain'):
                        # gbk解决中文编码，utf-8解决英文编码
                        # 打印邮件体
                        print(str(part.get_payload(decode=True), 'gbk'))
                        print('\n')
                        # 只要打印了一次就返回，解决原始邮件体和html版本邮件体重复度读取的问题
                        return
                    # 如果是html
                    elif content_type == 'text/html':
                        # 把邮件转换为html格式
                        a = str(part.get_payload(decode=True), 'gbk')
                        # 编写正则表达式匹配汉字
                        b = re.compile(u"[\u4e00-\u9fa5]{1,2}")
                        # 匹配汉字
                        c = b.findall(a)
                        # 输出匹配结果
                        for i in c:
                            print(i, end='')
                        print('\n')
                        return
                except:
                    if (content_type == 'text/plain'):
                        # 打印邮件体
                        print(str(part.get_payload(decode=True), 'utf-8'))
                        print('\n')
                        return
                    elif content_type == 'text/html':
                        # print(str(part.get_payload(decode=True), 'gbk'))
                        # 把邮件转换为html格式
                        a = str(part.get_payload(decode=True), 'utf-8').encode('utf-8')
                        # 编写正则表达式匹配汉字
                        b = re.compile(u"[\u4e00-\u9fa5]{1,2}")
                        # 匹配并输出匹配结果
                        c = b.findall(a)
                        for i in c:
                            print(i)
                        print('\n')
                        return
            else:
                # 如果有附件，打印附件名并将附件保存到指定目录
                # 目前是如果有附件，则不读附件，只读文本
                dh = email.header.decode_header(name)
                fname = dh[0][0]
                encode_str = dh[0][1]
                if encode_str != None:
                    if charset == None:
                        fname = fname.decode(encode_str, 'gbk')
                    else:
                        fname = fname.decode(encode_str, charset)
                data = part.get_payload(decode=True)
                # 打印附件名称
                print('Attachment : ' + fname)
                # 保存附件
                if fname != None or fname != '':
                    savefile(fname, data, '')


def savefile(filename, data, path):
    """
    保存文件方法（都是保存在指定的根目录下）
    :param filename:
    :param data:
    :param path:
    :return:
    """
    try:
        # 文件名
        filepath = path + filename
        print('Saved as ' + filepath)
        f = open(filepath, 'wb')
    except:
        print('filename error')
        f.close()
    f.write(data)
    f.close()


def getEmailHost(adress):
    """
    根据邮箱后缀选取邮箱应该使用的host
    :param adress:
    :return:
    """
    p = re.findall('@(.*?).com', adress)
    if p[0] == 'qq':
        return 'imap.qq.com'
    elif p[0] == '163':
        return 'imap.163.com'
    elif p[0] == 'outlook':
        return 'imap-mail.outlook.com'
    return None


def confirmEmailFormat(adress):
    """
    根据输入的邮箱判断邮箱格式是否正确
    :param adress:
    :return:
    """
    p = re.match('\w[-\w.+]*@([A-Za-z0-9][-A-Za-z0-9]+\.)+[A-Za-z]{2,14}', adress)
    if p == None:
        return '邮箱格式错误！'
    else:
        return '邮箱格式正确！'


def logIn(username, password):
    """
    登录邮箱
    :param host:
    :param username:
    :param password:
    :param port:
    :return:
     """

    resultlist=[]
    # 在此处判断邮箱格式是否正确
    p = re.match('\w[-\w.+]*@([A-Za-z0-9][-A-Za-z0-9]+\.)+[A-Za-z]{2,14}', username)
    if p == None:
        resultlist.append('邮箱格式错误')
        return resultlist
    else:
        pass

    # 在此处根据邮箱后缀获取
    host = getEmailHost(username)

    # 在此处执行登录操作
    try:
        # 使用IMAP4_SSL，通过SSL加密的套接字连接
        serv = imaplib.IMAP4_SSL(host, 993)
    except Exception as e:
        try:
            # 使用IMAP4连接
            serv = imaplib.IMAP4(host, 143)
        except Exception as e:
            resultlist.append('连接失败，请检查服务器和端口名称！')
            return resultlist

    try:
        # 登录邮箱
        serv.login(username, password)
    except:
        resultlist.append('登陆失败，请检查您的邮箱和密码是否正确！')
        return resultlist

    resultlist.append('登陆成功！')
    resultlist.append(serv)

    return resultlist


def checkNewMail(serv):
    serv.select('INBOX')  # 参数可以选择收件文件夹
    typ, data = serv.search(None, 'ALL')
    num_old = len(data[0].split())
    while True:
        time.sleep(3)
        #进行更新
        typ, data = serv.search(None, 'ALL')
        num_new = len(data[0].split())
        if num_new == num_old:
            pass
        else:
            print('您收到了一封新邮件！')
            for num in range(num_old,num_new):
                typ, data = serv.fetch(data[0].split()[num], '(RFC822)')
                # 数据元组
                text = data[0][1]
                # 编码方式
                encoding = chardet.detect(text)['encoding']
                new_text = str(text, encoding)
                # 转换为email.Message对象
                message = email.message_from_string(new_text)
                # 解析邮件头部
                parseHeader(message)
                # 解析邮件体
                parseBody(message)
                # 更新邮件数量
            num_old = num_new


def getAllMail(serv):
    # IMAP4.select([mailbox[, readonly]])第一个参数是邮箱名，默认是INBOX，readonly是只能读，不能修改
    serv.select('Junk')  # 参数可以选择收件文件夹
    # IMAP4.search()第二个参数：All,Unseen,Seen,Recent,Answered, Flagged，返回
    typ, data = serv.search(None, 'ALL')
    # 通过编号遍历search出的所有邮件
    for num in data[0].split():
        try:
            # 打印邮件序号
            typ, data = serv.fetch(num, '(RFC822)')
            # 数据元组
            text = data[0][1]
            new_text = str(text, encoding=chardet.detect(text)['encoding'])
            # 转换为email.message对象
            message = email.message_from_string(new_text)  # 转换为email.message对象
            # 解析邮件头部
            parseHeader(message)
            # 解析邮件体
            parseBody(message)
        except Exception as e:
            print(e)

    # serv.close()
    # serv.logout()

if __name__ == '__main__':
    username = "3389089691@qq.com"
    password = "rnhprnvdybxwciec"

    serv = logIn(username, password)
    getAllMail(serv)
