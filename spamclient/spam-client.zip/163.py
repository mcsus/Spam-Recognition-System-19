import imaplib
import email


def unicode(s, encoding):
    """
    获得字符码转换方法
    :param s:
    :param encoding:
    :return:
    """
    if encoding:
        return str(s, encoding)
    else:
        return str(s)


def get_charset(message, default="sacii"):
    """
    获得字符编码方法
    :param message:
    :param default:
    :return:
    """
    return message.get_charset()
    return default


def savefile(filename, data, path):
    """
    保存文件方法（都是保存在指定的根目录下）
    :param filename:
    :param data:
    :param path:
    :return:
    """
    try:
        filepath = path + filename
        print('Saved as ' + filepath)
        f = open(filepath, 'wb')
    except:
        print('filename error')
        f.close()
    f.write(data)
    f.close()


def parseHeader(message):
    """
    解析邮件首部
    :param message:
    :return:
    """
    subject = message.get('subject')
    dh = email.header.decode_header(subject)
    subject = unicode(dh[0][0], dh[0][1])  # .encode('gb2312')
    # 主题
    print('Subject:', subject)
    # 发件人
    print('From:', email.utils.parseaddr(message.get('from'))[1])
    # 收件人
    print('To:', email.utils.parseaddr(message.get('to'))[1])
    # 抄送人
    # print('Cc:',email.utils.parseaddr(message.get_all('cc'))[1])
    # 日期 date: Thu, 22 Aug 2019 08:48:32 +0800
    print("date:", message["Date"])


def parseBody(message, mypath='d:/mpathtest'):
    """
    解析邮件
    :param message:
    :param mypath:  附件保存目录
    :return:
    """
    for part in message.walk():  # 循环信件中的每一个mime的数据块
        if not part.is_multipart():
            filename = part.get_filename()
            charset = get_charset(part)
            # 有附件，将附件保存到指定目录
            if filename:
                dh = email.header.decode_header(filename)
                fname = dh[0][0]
                encode_str = dh[0][1]
                if encode_str != None:
                    if charset == None:
                        fname = fname.decode(encode_str, 'gbk')
                    else:
                        fname = fname.decode(encode_str, charset)
                data = part.get_payload(decode=True)
                #打印附件名称
                print('Attachment : ' + fname)
                # 保存附件，默认路径是mypath
                if fname != None or fname != '':
                    savefile(fname, data, mypath)
            else:
                # 没有附件，是文本内容
                # part 是Message类
                content_type = part.get_content_type()
                if content_type == 'text/plain':
                    try:
                        print(str(part.get_payload(decode=True), 'gbk'))  # gbk读取文本，utf-8读取图片信息
                    except Exception as e:
                        print(str(part.get_payload(decode=True), 'utf-8'))
                elif content_type == 'image/xyz':
                    # 图片不读
                    print("图片信息")
                else:
                    print(content_type)


def getMail(host, username, password):
    """
    登录邮箱
    :param host:
    :param username:
    :param password:
    :param port:
    :return:
    """
    try:
        serv = imaplib.IMAP4_SSL(host, 993)  # 使用IMAP4_SSL，通过SSL加密的套接字连接
        print("连接成功")
    except Exception as e:
        serv = imaplib.IMAP4(host, 143)  # 使用IMAP4连接
        print("连接成功")
    try:
        serv.login(username, password)  # 登录邮箱
    except Exception as e:
        print("登录失败，请检查邮箱和授权码")
    # 如果登录失败，返回失败原因(待做)

    serv.select()  # 参数可以选择收件文件夹
    typ, data = serv.search(None, 'ALL')  # 搜索邮件内容，ALL是搜索所有邮件
    # count = 1
    # pcount = 1

    # 读取收件箱中所有邮件信息，包括收发人、日期、邮件正文
    dataStr = data[0].split();
    print("data[0].split():", dataStr)  # 收件箱有6封邮件：[b'1', b'2', b'3', b'4', b'5', b'6']
    for num in data[0].split()[::-1]:
        typ, data = serv.fetch(num, '(RFC822)')
        text = data[0][1]
        print("num", num)
        try:
            new_text = str(text, encoding="utf-8")  # utf-8 or gb2312
        except Exception as e:
            new_text = str(text, encoding="gb2312")

        message = email.message_from_string(new_text)  # 转换为email.message对象

        parseHeader(message)  # 获取邮件首部
        parseBody(message)  # 获取邮件体

        print("\n")
        """
        pcount += 1
        if pcount > count:
            break
        """

    serv.close()
    serv.logout()


if __name__ == '__main__':
    host2 = "imap.163.com"
    username2 = "jingyi_d@163.com"
    passord2 = "shouquanma123"
    getMail(host2, username2, passord2)

    print("\n")

    host = "imap.qq.com"  # "pop.mail_serv.com"
    username = "532148605@qq.com"
    password = "bmtnvpuyzvckbghe"
    getMail(host, username, password)
