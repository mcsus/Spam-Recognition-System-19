import socket

link = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
link.connect(('localhost', 1024))

while True:
    data=input('>')
    if not data:
        pass
    link.send(data.encode())
link.close()