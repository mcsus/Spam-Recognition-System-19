
list=[False,False]

if ''